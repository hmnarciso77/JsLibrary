Never use comments in the code.

All JavaScript functions should have this syntax: $(function () { });,

All functions should start with a line comment explaining very concisely what the function does. This is the only comment that can be used.
