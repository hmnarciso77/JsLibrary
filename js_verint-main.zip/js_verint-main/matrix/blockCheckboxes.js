// Block checkboxes for specific questions
$(function () {
    $('#Q558C_A_1_2 > label').hide();
    $('#Q558C_A_3_2 > label').hide();
});